package HibernateTest.test.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

/**
 * Hello world!
 *
 */
public class App_Test 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Session session = HibernateUtil.getSessionFactory().openSession();
        
        session.beginTransaction();
        
        Query q = session.createQuery("from Emp ", Emp.class);
        
        List<Emp> resultList = q.list();
        System.out.println("num of employees:" + resultList.size());
        for (Emp next : resultList) {
                System.out.println("next employee: " + next.getEmail());
                Query q1 = session.createQuery("from Emp ", Emp.class);
                
                List<Emp> resultList1 = q1.list();
                System.out.println("num of employees:" + resultList1.size());
                for (Emp next1 : resultList1) {
                        System.out.println("next employee: " + next1.getEmail());
                }
        }
        
    }
}
